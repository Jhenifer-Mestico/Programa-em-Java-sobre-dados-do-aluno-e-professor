package aula06;

public class Professor extends Pessoa{
   
    private float salario;
    private String disciplinas;
    private int  numDeRegistro;

    public Professor () {
    }

    public Professor(float salario, String disciplinas, int numDeRegistro) {
        this.salario = salario;
        this.disciplinas = disciplinas;
        this.numDeRegistro = numDeRegistro;
    }

    public float getSalario() {
        return salario;
    }

    public String getDisciplinas() {
        return disciplinas;
    }

    public int getNumDeRegistro() {
        return numDeRegistro;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public void setDisciplinas(String disciplinas) {
        this.disciplinas = disciplinas;
    }

    public void setNumDeRegistro(int numDeRegistro) {
        this.numDeRegistro = numDeRegistro;
    }
    
    public void avaliarAluno(float nota1, float nota2, float frequencia){
        float media = (nota1 = nota2) / 2;
        
        if(frequencia < 75){
            System.out.println("Reprovado por falta"); 
        }else{
            if(media < 6){
                System.out.println("Reprovado por nota");
            }else{
                System.out.println("Aprovado");
            }
        }
        if (media > 6.0){ //tomada de decisao simples
            System.out.println("Aluno aprovado");
           
        }else{
            System.out.println("Aluno reprovado");
            
        }
    }
    
    
}
