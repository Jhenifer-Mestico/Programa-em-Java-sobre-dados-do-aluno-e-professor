package aula06;

public class Aula06 {

    public static void main(String[] args) {
        Aluno objAluno = new Aluno( 345, "ccp", "3h", 540.67f, 9.7f, 6.8f, 4.5f);
        objAluno.setNome("Jhe");
        objAluno.setAltura(1.45f);
        objAluno.setCpf("345.454.789.-89");
        objAluno.setEmail("jhe@gmail.com");
        objAluno.setIdade(17);
        objAluno.setPeso(56.7f);
        objAluno.setRg("46758475-x");
        
        System.out.println("Nome: " + objAluno.getNome());
        System.out.println("Curso: " + objAluno.getCurso());
        
        Professor objProfessor = new Professor(10.6f, "poo", 4557);
        objProfessor.setNome("João");
        objProfessor.setIdade(45);
        
        System.out.println("Nome do prof:" + objProfessor.getNome());
        System.out.println("Idade do prof:" + objProfessor.getIdade());
       
        objProfessor.avaliarAluno(objAluno.getNota1(), objAluno.getNota2(), objAluno.getFrequencia());
        
    }
    
}
