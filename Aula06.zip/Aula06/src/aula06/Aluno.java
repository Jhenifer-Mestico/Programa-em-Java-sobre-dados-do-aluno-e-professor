package aula06;

public class Aluno extends Pessoa{
    private int rgm;
    private String curso;
    private String turma;
    private float valorMensalidade;
    private float nota1;
    private float nota2;
    private float frequencia;
    
    public Aluno() {
    }

    public Aluno(int rgm, String curso, String turma, float valorMensalidade, float nota1, float nota2, float frequencia) {
        this.rgm = rgm;
        this.curso = curso;
        this.turma = turma;
        this.valorMensalidade = valorMensalidade;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.frequencia = frequencia;
    }

    public int getRgm() {
        return rgm;
    }

    public String getCurso() {
        return curso;
    }

    public String getTurma() {
        return turma;
    }

    public float getValorMensalidade() {
        return valorMensalidade;
    }

    public float getNota1() {
        return nota1;
    }

    public float getNota2() {
        return nota2;
    }

    public float getFrequencia() {
        return frequencia;
    }

    public void setRgm(int rgm) {
        this.rgm = rgm;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public void setTurma(String turma) {
        this.turma = turma;
    }

    public void setValorMensalidade(float valorMensalidade) {
        this.valorMensalidade = valorMensalidade;
    }

    public void setNota1(float nota1) {
        this.nota1 = nota1;
    }

    public void setNota2(float nota2) {
        this.nota2 = nota2;
    }
    
    public void setFrequencia(float frequencia) {
        this.frequencia = frequencia;
    }
    
}